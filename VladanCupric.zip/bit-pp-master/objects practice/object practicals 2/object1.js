function convertANumber(number){

    return hexadec = parseInt (number, 16). toString(8);

}

console.log(convertANumber("ff"));