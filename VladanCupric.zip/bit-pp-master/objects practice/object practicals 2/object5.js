// Write a function to split a string and convert it into an array of words.

// 	"John Snow" -> [ 'John', 'Snow' ]

function splitAString (someStr) {
    return someStr.split(" ");
}

console.log(splitAString("John Snow"));