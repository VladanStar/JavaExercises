// Create an object that represents your favourite movie. Please include title, actors, director, genre, popularity.

var favouriteMovie = {
    title: "Thor Ragnarok",
    actors: ["Chris Hemsworth", "Tom Hiddleston", "Cate Blanchett", "Jeff Goldblum", "Mark Ruffalo"],
    director: "Taika Waitti",
    genre: "action",
    popularity: "worldwide"
}

console.log(favouriteMovie);