// Create an object that represents your favourite coffee. Please include coffee name, strength, flavour, milk, sugar, … everything you like!

var favoriteCoffee = {
    name: "rucno pravljena",
    strength: "koliko stavim",
    flavour: "nista bez mleka",
    milk: "al' sa laktozom",
    sugar: "moze"
}

console.log(favoriteCoffee);
