var randomString = "";

function isBlank (input){
    if (input === "") {
        return true;
    } else {
        return false;
    }
}

console.log(isBlank(randomString));