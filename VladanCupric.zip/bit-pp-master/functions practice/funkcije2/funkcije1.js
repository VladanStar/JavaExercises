var randomInput ="hgdyety";
function isString(input) {
    
    if(typeof input === "string") {
        return true;
    } else {
        return false;
    }
}

console.log(isString(randomInput));