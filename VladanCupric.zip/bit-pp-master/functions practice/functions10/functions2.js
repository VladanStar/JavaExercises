"use strict" ;

var rectangleSurface= (function(a, b){
    return a * b;
}(4,5));

console.log(rectangleSurface);