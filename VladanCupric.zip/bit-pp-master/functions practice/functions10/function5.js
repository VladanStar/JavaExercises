function octalToDecimal(octalNum) {
    var str = octalNum + "";
    
    return parseInt(str);
}



console.log(octalToDecimal(034));
