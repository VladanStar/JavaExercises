var print =function () {
    return console.log;
 };
 
 print()("This might work or not?");

