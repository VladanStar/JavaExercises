var oddNumber = 8;

function isOdd (a) {
    if (a % 2 !== 0 ) {
        console.log(true);
    } else {
        console.log (false);
    }
}

isOdd(oddNumber);
