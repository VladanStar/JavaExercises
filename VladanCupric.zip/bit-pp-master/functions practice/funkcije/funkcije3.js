
function isThreeDigit (number) {
    if(number >= 100 && number < 1000) {
        console.log(true);
    } else {
        console.log(false);
    }
}

isThreeDigit(56);