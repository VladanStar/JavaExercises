

function calcMax (a, b) {
    max = 0;
    if (a>b) {
        max = a;
    } else {
        max = b;
    }

    return max;
}
calcMax(8,12);
console.log(max);
