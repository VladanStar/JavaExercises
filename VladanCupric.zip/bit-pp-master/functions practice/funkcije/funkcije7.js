var number = 254578;


function numberOfDigits (a) {
    var length =0;
    a = a+ "";
    length = a.length;
    return length;

}


console.log(numberOfDigits(number));